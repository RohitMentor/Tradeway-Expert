<?php
$name = $_POST["name"];
$phone = $_POST["phone"];
$email = $_POST["email"];
$state_name = $_POST["state_name"];
$investment = $_POST["investment"];
$segment = $_POST["segment"];

$to = "experttradewaysales@gmail.com";
$subject = "Enquiry Form Submited";

$message = "
<html>
<head>
<title>Hellow Sir/Mam</title>
</head>
<body>
<p>Need information about investment.</p>
<table>
<tr>
<th>Name</th>
<th>Phone</th>
<th>email</th>
<th>state_name</th>
<th>investment</th>
<th>segment</th>
</tr>
<tr>
<td>$name</td>
<td>$phone</td>
<td>$email</td>
<td>$state_name</td>
<td>$investment</td>
<td>$segment</td>
</tr>
</table>
</body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From:'. $email . "\r\n";

mail($to,$subject,$message,$headers);

header("Location: index.html");
?>